const Joi = require('joi');
const dotenv = require('dotenv');

dotenv.config();
const validateImage = (req, res, next) => {
    const schema = Joi.object({
        file: Joi.object({
            size: Joi.number().max(parseInt(process.env.MAX_IMAGE_SIZE)).required(),
            mimetype: Joi.string().valid(...process.env.ALLOWED_IMAGE_TYPES.split(',')).required()
        }).required()
    })

    const error = schema.validate({file:req.file})
    if(error){
        return res.status(400).json({message:" `File validation failed: ${error.details[0].message}`"});
    }
    next();
}

module.exports = validateImage