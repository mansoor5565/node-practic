const express = require('express')
const dotenv = require('dotenv')
const upload = require('./config/multerConfig.js');
const validateImage = require('./validators/imageValidator.js')